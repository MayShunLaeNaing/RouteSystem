<?php 


	require "views/contact.view.php";

?>