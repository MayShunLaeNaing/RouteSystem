<?php 

	return [
		"database"=>[

			"username"=>"root",
			"password"=>"",
			"dbname"=>"todo",
			"host"=>"mysql:host=localhost"

		]


	];

?>