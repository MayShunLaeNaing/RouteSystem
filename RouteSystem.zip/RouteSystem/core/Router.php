<?php 

	class Router{

		public static function load($filename){
			$router=new Router;
			require $filename;
			return $router;
		}
		protected $routes=[];

		//""=>"Controller/IndexController.php",
		//"about"=>"Controller/AboutController.php",
		//"contact"=>"Controller/ContactController.php",
		public function register($routes)
		{
			$this->routes=$routes;
		}
		public function direct($uri) 
		{
			if(array_key_exists($uri,$this->routes ))
			{
				return $this->routes[$uri];
			}
		}
	}

?>