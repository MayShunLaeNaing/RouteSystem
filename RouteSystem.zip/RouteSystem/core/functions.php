<?php

	
	function dd($data) {
		echo "<pre>";
		die(var_dump($data));
	}

?>