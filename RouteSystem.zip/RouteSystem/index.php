<?php

	
	require "core/bootstrap.php";

	
	
		//
		
		//require $router->direct(trim($_SERVER['REQUEST_URI'],"/"));
		
		require Router::load("routes.php")->direct(trim($_SERVER['REQUEST_URI'],"/"));

?>