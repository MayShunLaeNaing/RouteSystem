<?php 

	$router->register([

		""=>"Controller/IndexController.php",
		"about"=>"Controller/AboutController.php",
		"contact"=>"Controller/ContactController.php",
	]);

	?>