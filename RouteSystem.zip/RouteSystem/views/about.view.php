<?php require "views/partial/heading.php" ?>
	<h1>about</h1>
	<a href="/">home</a>
<?php require "views/partial/footer.php" ?>