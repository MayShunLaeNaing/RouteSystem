<?php require "views/partial/heading.php"; ?>
	<h1>Contact</h1>
	
<?php require "views/partial/footer.php"; ?>