<?php require "views/partial/heading.php"; ?>

	<nav>
		<a href="/">Home</a>
		<a href="/about">About</a>
		<a href="/contact">Contact</a>
	</nav>
	<h1>My todo</h1>
	<?php foreach($tasks as $task) : ?>

	<?php

		if($task->complete){
		echo "<strike>$task->description</strike><br>";
	}
		else{
		echo "$task->description<br>";
	}

	?>
	<?php endforeach; ?>

<?php require "views/partial/footer.php"; ?>
